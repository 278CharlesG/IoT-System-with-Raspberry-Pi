from django.shortcuts import render
from django.shortcuts import render
from .models import Entry
def index(request):
    return render(request, 'blog/index.html')
def blog(request):
    entries = Entry.objects.all()
    context = {'entries' : entries} # Store the data in "context" dictionaries
    return render(request, 'blog/blog.html', context)

