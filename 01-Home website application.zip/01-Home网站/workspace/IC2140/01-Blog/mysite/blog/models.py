from django.db import models
class Entry(models.Model):
    #Fields
    text = models.TextField()
    date_posted = models.DateTimeField(auto_now_add=True)
    #Methods
    def __str__(self):
        return 'Entry #{}'.format(self.id)
    class Meta:
        verbose_name_plural = 'entries'