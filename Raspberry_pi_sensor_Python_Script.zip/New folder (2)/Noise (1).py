import RPi.GPIO as GPIO
import time
import math
from RPLCD.i2c import CharLCD
import Adafruit_ADS1x15


output_channel = [18, 24, 23, 25, 8]  #
BUTTON_PIN = 22  # Peak reset button
ADC_80DB_VALUE = 1300  

# Initialize LCD
lcd = CharLCD('PCF8574', 0x27)

# Initialize GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(output_channel, GPIO.OUT, initial=GPIO.LOW)
GPIO.setup(BUTTON_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)

# Initialize ADC
adc = Adafruit_ADS1x15.ADS1115()
GAIN = 1



# Global variables
peak_dB = 0

def adc_to_dB(adc_value):
    """Convert ADC value to dB: dB = 20*log10(adc_value/ADC_80DB_VALUE) + 80"""
    if adc_value <= 0:
        return 0
    return 20 * math.log10(adc_value / ADC_80DB_VALUE) + 80

def update_led_level(dB_value):
    """Control LEDs based on dB thresholds"""
    thresholds = [60, 65, 70, 75, 80]  # dB thresholds for each LED
    for i, threshold in enumerate(thresholds):
        GPIO.output(output_channel[i], GPIO.HIGH if dB_value >= threshold else GPIO.LOW)

def check_button():
    """Check if button is pressed to reset peak dB"""
    global peak_dB
    if not GPIO.input(BUTTON_PIN):
        peak_dB = 0
        time.sleep(0.2)  

def create_noise_bar(dB_value, max_dB=100, bar_length=16):
    """Create a visual noise level bar for LCD"""
    filled = min(int((dB_value / max_dB) * bar_length), bar_length)
    return '[' + '@' * filled + ' ' * (bar_length - filled - 2) + ']'

try:
    print("Sound Level Meter - Continuous Demo Mode")
    print("Press Ctrl-C to quit...")
    print('| {0:>6} | {1:>6} | {2:>6} | {3:>6} |'.format(*range(4)))
    print('-' * 37)
    
    lcd.clear()
    lcd.write_string("Sound Level Meter")
    time.sleep(1)
    lcd.clear()
    lcd.write_string("Using ADC Ch3...")
    time.sleep(1)
    lcd.clear()

    while True:
        # Read all ADC channels
        values = [0] * 4
        for i in range(4):
            values[i] = adc.read_adc(i, gain=GAIN)
        
        # Print all values to console
        print('| {0:>6} | {1:>6} | {2:>6} | {3:>5} |'.format(*values))
        
        # Get dB value from channel 3 (values[2])
        current_dB = adc_to_dB(values[2])
        
        # Update peak dB
        if current_dB > peak_dB:
            peak_dB = current_dB
        
        
        lcd.cursor_pos = (0, 0)
        lcd.write_string(f"Now:{current_dB:>4.1f} Peak:{peak_dB:>4.1f}")
        
        
        lcd.cursor_pos = (1, 0)
        noise_bar = create_noise_bar(current_dB)
        lcd.write_string(noise_bar)
        
        # Update LEDs
        update_led_level(current_dB)
        
        # Check for button press
        check_button()
        
        
        time.sleep(0.1)

except KeyboardInterrupt:
    print("\nExiting program...")
finally:
    # Clean up
    GPIO.cleanup()
    lcd.clear()
    lcd.write_string("Demo Stopped!")
    time.sleep(1)
    lcd.clear()