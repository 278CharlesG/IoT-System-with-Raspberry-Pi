import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(18,GPIO.OUT,initial=1)
GPIO.setup(23,GPIO.OUT,initial=1)
GPIO.setup(24,GPIO.OUT,initial=1)
GPIO.setup(25,GPIO.OUT,initial=1)
GPIO.setup(8,GPIO.OUT,initial=1)
input_channel=[20,21]
output_channel=[18,23,24,25,8]
GPIO.setup(input_channel,GPIO.IN,pull_up_down=GPIO.PUD_UP)
GPIO.setup(output_channel,GPIO.OUT,initial=GPIO.PUD_UP)
GPIO.setwarnings(False)

try:
    while (1):
        if GPIO.input(20)==0:
            while (True):

                GPIO.output(18, True)
                GPIO.output(23, False)
                GPIO.output(24, False)
                GPIO.output(25, False)
                GPIO.output(8, False)
                time.sleep(0.5)
                GPIO.output(18, False)
                GPIO.output(23, True)
                GPIO.output(24, False)
                GPIO.output(25, False)
                GPIO.output(8, False)
                time.sleep(0.5)
                GPIO.output(18, False)
                GPIO.output(23, False)
                GPIO.output(24, True)
                GPIO.output(25, False)
                GPIO.output(8, False)
                time.sleep(0.5)
                GPIO.output(18, False)
                GPIO.output(23, False)
                GPIO.output(24, False)
                GPIO.output(25, True)
                GPIO.output(8, False)
                time.sleep(0.5)
                GPIO.output(18, False)
                GPIO.output(23, False)
                GPIO.output(24, False)
                GPIO.output(25, False)
                GPIO.output(8, True)
                time.sleep(0.5)
                print("Port20 is low - Button 2 pressed")
                if (GPIO.input(21)==0):
                    break
        if GPIO.input(21)==0:
            while True:
                GPIO.output(18, False)
                GPIO.output(23, False)
                GPIO.output(24, False)
                GPIO.output(25, False)
                GPIO.output(8, True)
                time.sleep(0.5)
                GPIO.output(18, False)
                GPIO.output(23, False)
                GPIO.output(24, False)
                GPIO.output(25, True)
                GPIO.output(8, False)
                time.sleep(0.5)
                GPIO.output(18, False)
                GPIO.output(23, False)
                GPIO.output(24, True)
                GPIO.output(25, False)
                GPIO.output(8, False)
                time.sleep(0.5)
                GPIO.output(18, False)
                GPIO.output(23, True)
                GPIO.output(24, False)
                GPIO.output(25, False)
                GPIO.output(8, False)
                time.sleep(0.5)
                GPIO.output(18, True)
                GPIO.output(23, False)
                GPIO.output(24, False)
                GPIO.output(25, False)
                GPIO.output(8, False)
                time.sleep(0.5)
           
                print("Port21 is low - Button 2 pressed")
        if GPIO.input(20) == 1 and GPIO.input(21) == 1:
            GPIO.output(output_channel, False)
            print("Buttons 1 & 2 not pressed")
        if GPIO.input(20) == 0 and GPIO.input(21) == 0:
            GPIO.output(output_channel, False)
            print("Buttons 1 & 2 pressed")
except KeyboardInterrupt:
    GPIO.cleanup()
    print("END OF PROGRAM")
