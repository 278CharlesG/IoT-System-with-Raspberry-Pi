#24109905d   #24127626d
import RPi.GPIO as GPIO
import time
import sys
from RPLCD.i2c import CharLCD
import Adafruit_ADS1x15
output_channel = 18,24,23,25,8

lcd = CharLCD('PCF8574', 0x27)

GPIO.setmode(GPIO.BCM)
GPIO.setup(output_channel, GPIO.OUT,initial=GPIO.LOW)
adc = Adafruit_ADS1x15.ADS1115()
GAIN = 1

print('Reading ADS1x15 values, press Ctrl-C to quit...')
print('| {0:>6} | {1:>6} | {2:>6} | {3:>6} |'.format(*range(4)))
print('-' * 37)

while True:
    values = [0] * 4
    for i in range(4):
        values[i] = adc.read_adc(i, gain=GAIN)
    print('| {0:>6} | {1:>6} | {2:>6} | {3:>5} |'.format(*values))   
    time.sleep(0.5)
    vol = values[1] / (2**15)*4.096*GAIN
    ADC = values[1]
    a = "Voltage: {:.2f}".format(vol)
    b = "ADC: {:.2f}".format(ADC)
    lcd.cursor_pos = (0,0)
    lcd.write_string(a)
    lcd.cursor_pos = (1,0)
    lcd.write_string(b)
    if values[1] >= 25600: #U=3.23v
        GPIO.output(18,True)
        GPIO.output(24,False)
        GPIO.output(23,False)
        GPIO.output(25,False)
        GPIO.output(8,False)
    elif values[1] >= 20000 and values[1] < 25600: #U=2.5v
        GPIO.output(18,False)
        GPIO.output(23,True)
        GPIO.output(24,False)
        GPIO.output(25,False)
        GPIO.output(8,False)
    elif values[1] >= 13500 and values[1] < 20000: #U=1.7v
        GPIO.output(18,False)
        GPIO.output(23,False)
        GPIO.output(24,True)
        GPIO.output(25,False)
        GPIO.output(8,False)
    elif values[1] >= 6200 and values[1] < 13500:#U=0.8v
        GPIO.output(18,False)
        GPIO.output(23,False)
        GPIO.output(24,False)
        GPIO.output(25,True)
        GPIO.output(8,False)
    elif values[1] >= 780 and values[1] < 6200:#U=0.1v
        GPIO.output(18,False)
        GPIO.output(24,False)
        GPIO.output(23,False)
        GPIO.output(25,False)
        GPIO.output(8,True)
    else: 
        GPIO.output(18,False)
        GPIO.output(23,False)
        GPIO.output(24,False)
        GPIO.output(25,False)
        GPIO.output(8,False)