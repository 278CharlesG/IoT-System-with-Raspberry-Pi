import RPi.GPIO as GPIO
import Adafruit_DHT
import time
from RPLCD.i2c import CharLCD
from datetime import datetime

def log_to_file(temp,hum):
    timestamp = datetime.now().strftime("%Y-%m-%d %h:%M:%S.%f")
    log_entry=f"Time={timestamp} {temp} {hum}\n"
    with open("abc.txt","a")as f:
        f.write(log_entry)
    print(log_entry.strip())
DHT_SENSOR = Adafruit_DHT.DHT11
DHT_PIN = 4
lcd = CharLCD('PCF8574', 0x27)

GPIO.setmode(GPIO.BCM)
GPIO.setup(DHT_PIN, GPIO.IN, GPIO.PUD_UP)

filename = "abc.txt"
with open(filename,'a') as file:
    file.write("a")
    pass

try:
    Adafruit_DHT.DHT11 = 1
except NotImplementedError:
    Adafruit_DHT.DHT11 = None

while True:
    humidity, temperature = Adafruit_DHT.read_retry(DHT_SENSOR, DHT_PIN)
    if humidity is not None and temperature is not None:
        print("TEMP={0:0.1f}C Humidity={1:0.1f}%".format(temperature, humidity))
        lcd.cursor_pos = (0, 0)
        lcd.write_string("TEMP:{0:0.1f}".format(temperature))
        lcd.cursor_pos = (0, 9)
        lcd.write_string(chr(0xdf)+"C")
        lcd.cursor_pos = (1, 0)
        lcd.write_string("Humidity:{0:0.1f}%".format(humidity))
        log_to_file(temperature,humidity)
        with open(filename,'a') as file:
            file.write("TEMP:{0:0.1f}  ".format(temperature))
            file.write("Humidity:{0:0.1f}% \n".format(humidity))
            
    else:
        print("Sensor failure. Check wiring.");
