import RPi.GPIO as GPIO
from RPLCD.i2c import CharLCD
import time
import datetime


LED_PINS = [8, 17]
OUTPUT_CHANNEL = 18
INPUT_CHANNELS = [20,21]

# Setup GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(LED_PINS, GPIO.OUT, initial=GPIO.LOW)
GPIO.setup(OUTPUT_CHANNEL, GPIO.OUT, initial=GPIO.LOW)
GPIO.setup(INPUT_CHANNELS, GPIO.IN, pull_up_down=GPIO.PUD_UP)

# Initialize LCD
lcd = CharLCD('PCF8574', 0x27)

# Create custom characters
smiley = (
    0b00000,
    0b01010,
    0b01010,
    0b00000,
    0b10001,
    0b10001,
    0b01110,
    0b00000
)

sad = (
    0b00000,
    0b01010,
    0b01010,
    0b00000,
    0b01110,
    0b10001,
    0b10001,
    0b00000
)

lcd.create_char(0, smiley)
lcd.create_char(1, sad)

icons = ['\x00', '\x01']
icon_index = 0

# Initial display setup
lcd.clear()
lcd.cursor_pos = (0, 3)
lcd.write_string("Real Time")
lcd.cursor_pos = (1, 0)
lcd.write_string("Time: ")

try:
    while True:
        current_time = datetime.datetime.now().strftime("%H:%M:%S")
        GPIO.output(LED_PINS[0], not GPIO.input(LED_PINS[0]))
        GPIO.output(LED_PINS[1], not GPIO.input(LED_PINS[1]))
        lcd.cursor_pos = (1, 6)
        lcd.write_string(current_time)
        lcd.cursor_pos = (1, 8)
        lcd.write_string(' ' if int(time.time()) % 2 == 0 else ':')
        lcd.cursor_pos = (0, 13)
        lcd.write_string(icons[icon_index])
        icon_index = (icon_index + 1) % len(icons)
        for channel in INPUT_CHANNELS:
            if GPIO.input(channel) == GPIO.LOW:
                if channel == 20:
                    GPIO.output(OUTPUT_CHANNEL, GPIO.HIGH)
                    print("SW2: Output ON")
                elif channel == 21:
                    GPIO.output(OUTPUT_CHANNEL, GPIO.LOW)
                    print("SW1: Output OFF")
                time.sleep(0.3)
        time.sleep(1)

except KeyboardInterrupt:
    lcd.clear()
    lcd.write_string("Program Stopped")
    time.sleep(2)
    lcd.backlight_enabled = False
    lcd.close(clear=True)
    GPIO.cleanup()
    print("\nProgram terminated")