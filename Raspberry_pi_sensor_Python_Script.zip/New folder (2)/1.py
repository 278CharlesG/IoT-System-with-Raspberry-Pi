Serving Flask app "iot_sensor" (lazy loading)
 * Environment: production
   WARNING: This is a development server. Do not use it in a production deployment.
   Use a production WSGI server instead.
 * Debug mode: on
Traceback (most recent call last):
  File "/home/pi/Desktop/iot_sensor.py", line 80, in <module>
    app.run(host='0.0.0.0', port=80, debug=True)
  File "/usr/lib/python3/dist-packages/flask/app.py", line 990, in run
    run_simple(host, port, self, **options)
  File "/usr/lib/python3/dist-packages/werkzeug/serving.py", line 1030, in run_simple
    s.bind(server_address)
PermissionError: [Errno 13] Permission denied
>>> 
