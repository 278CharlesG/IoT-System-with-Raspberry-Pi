#24109905d(Chen wenrui) #24127626d(Ge Yunjie)
import time
import threading
from RPLCD.i2c import CharLCD
import RPi.GPIO as GPIO

# Hardware setup
LCD_ADDRESS = 0x27
LED_PIN = 18
BUZZER_PIN = 26
SW1_PIN = 20  # Start/Stop button
SW2_PIN = 21  # Add time button

# Initialize hardware
lcd = CharLCD('PCF8574', LCD_ADDRESS, cols=16, rows=2)
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(LED_PIN, GPIO.OUT)
GPIO.setup(BUZZER_PIN, GPIO.OUT)
GPIO.setup(SW1_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(SW2_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)

# Stopwatch states
MENU = 0
SETTING = 1
RUNNING = 2
ALARM = 3

def create_custom_chars():
    """Create custom characters for emoji animations"""
    chars = [
        [0b00000, 0b01010, 0b01010, 0b00000, 0b10001, 0b01110, 0b00000, 0b00000],  # Smile 0
        [0b00000, 0b01010, 0b01010, 0b00000, 0b01110, 0b10001, 0b00000, 0b00000],  # Frown 1
        [0b00000, 0b01010, 0b01010, 0b00000, 0b00000, 0b01110, 0b00000, 0b00000],  # Neutral 2
    ]
    for i, char in enumerate(chars):
        lcd.create_char(i, char)

class Stopwatch:
    def __init__(self):
        self.state = MENU
        self.time_set = 60  
        self.time_remaining = 60
        self.last_update = 0
        self.animation_frame = 0
        self.scroll_text = "<<< Cnt down ! <<< "
        self.scroll_pos = 0
        self.buzzer_pwm = None
        self.last_sw1_state = True
        self.last_sw2_state = True
        self.last_state = None
        
        create_custom_chars()
        self.show_menu()
        
    def show_menu(self):
        """Display welcome menu"""
        lcd.clear()
        lcd.cursor_pos = (0, 0)
        lcd.write_string("Mini-Project One")
        lcd.cursor_pos = (1, 0)
        lcd.write_string("Stopwatch start")
        time.sleep(2)
        self.state = SETTING
        self.update_display()
        
    def update_display(self):
        """Update LCD based on current state"""
        if self.state != self.last_state:
            lcd.clear()
            self.last_state = self.state
            
        if self.state == SETTING:
            # Calculate hours, minutes, seconds
            hours = self.time_set // 3600
            minutes = (self.time_set % 3600) // 60
            seconds = self.time_set % 60
            
            lcd.cursor_pos = (0, 0)
            lcd.write_string("Set Time:")
            lcd.cursor_pos = (0, 10)
            lcd.write_string(f"{hours:02d}:{minutes:02d}:{seconds:02d}")
            lcd.cursor_pos = (1, 0)
            lcd.write_string("SW1:Start SW2:Add")
            
        elif self.state == RUNNING:
            # Calculate hours, minutes, seconds
            hours = self.time_remaining // 3600
            minutes = (self.time_remaining % 3600) // 60
            seconds = self.time_remaining % 60
            
            # Display emoji in upper left corner
            lcd.cursor_pos = (0, 0)
            lcd.write_string(chr(self.animation_frame % 3))
            
            # Display time in HH:MM:SS format centered
            lcd.cursor_pos = (0, 4)
            lcd.write_string(f"{hours:02d}:{minutes:02d}:{seconds:02d}")
            
            
            display_width = 16
            text_length = len(self.scroll_text)
            padded_text = self.scroll_text * 3  # Repeat text for smooth scrolling
            
            start_pos = self.scroll_pos % text_length
            end_pos = start_pos + display_width
            visible_text = padded_text[start_pos:end_pos]
            
            lcd.cursor_pos = (1, 0)
            lcd.write_string(visible_text[:display_width])
            
        elif self.state == ALARM:
            lcd.cursor_pos = (0, 0)
            lcd.write_string("Press SW1 to reset")
            lcd.cursor_pos = (1, 0)
            lcd.write_string("TIME'S UP!")
            
            if int(time.time()) % 2 == 0:
                lcd.cursor_pos = (1, 15)
                lcd.write_string(chr(1))  # Frown face
    
    def handle_buttons(self):
        """Button handling with edge detection"""
        current_sw1 = GPIO.input(SW1_PIN)
        current_sw2 = GPIO.input(SW2_PIN)
        
        # Detect falling edge (button press)
        if self.last_sw1_state and not current_sw1:
            if self.state == SETTING:
                self.state = RUNNING
                self.time_remaining = self.time_set
                self.last_update = time.time()
            elif self.state == RUNNING:
                self.state = SETTING
            elif self.state == ALARM:
                self.state = SETTING
                if self.buzzer_pwm:
                    self.buzzer_pwm.stop()
                    GPIO.output(BUZZER_PIN, GPIO.LOW)
            time.sleep(0.1)  # Debounce
            
        
        if self.last_sw2_state and not current_sw2 and self.state == SETTING:
            self.time_set += 60
            if self.time_set > 86399:  
                self.time_set = 60
            self.update_display()
            time.sleep(0.1)
            
        self.last_sw1_state = current_sw1
        self.last_sw2_state = current_sw2
    
    def update(self):
        """Main update loop"""
        while True:
            self.handle_buttons()
            
            if self.state == RUNNING:
                current_time = time.time()
                if current_time - self.last_update >= 1:
                    self.time_remaining -= 1
                    self.last_update = current_time
                    
                    GPIO.output(LED_PIN, GPIO.HIGH)
                    time.sleep(0.1)
                    GPIO.output(LED_PIN, GPIO.LOW)
                    
                    # Cycle through emoji frames
                    self.animation_frame += 1
                    
                    if self.time_remaining <= 0:
                        self.state = ALARM
                        self.time_remaining = 0
                        if not self.buzzer_pwm:
                            self.buzzer_pwm = GPIO.PWM(BUZZER_PIN, 1000)
                        self.buzzer_pwm.start(50)
            
            
            if self.state == RUNNING:
                self.scroll_pos += 1
            
            if self.state == ALARM:
                freq = 500 + int((time.time() % 3) * 1000)
                if self.buzzer_pwm:
                    self.buzzer_pwm.ChangeFrequency(freq)
                    self.buzzer_pwm.ChangeDutyCycle(50)
            
            self.update_display()
            time.sleep(0.1)  # Overall refresh rate

# Run the stopwatch
stopwatch = Stopwatch()
stopwatch_thread = threading.Thread(target=stopwatch.update, daemon=True)
stopwatch_thread.start()

try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    if stopwatch.buzzer_pwm:
        stopwatch.buzzer_pwm.stop()
    GPIO.output(BUZZER_PIN, GPIO.LOW)
    lcd.close(clear=True)
    GPIO.cleanup()